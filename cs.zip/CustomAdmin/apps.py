from django.apps import AppConfig


class CustomadminConfig(AppConfig):
    name = 'CustomAdmin'
