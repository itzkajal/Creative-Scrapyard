from django.contrib import admin
from .models import *

# Register your models here.
admin.site.register(tbl_creativeitems_mst)
admin.site.register(tbl_crtimages)
admin.site.register(tbl_scrapitems)
admin.site.register(tbl_scrapimages)
admin.site.register(Reviews)
admin.site.register(Issues)
