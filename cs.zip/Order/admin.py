from django.contrib import admin
from .models import *

# Register your models here.
admin.site.register(tbl_orders_mst)
admin.site.register(tbl_orders_details)