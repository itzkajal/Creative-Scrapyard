from django.apps import AppConfig


class ValidationsConfig(AppConfig):
    name = 'Validations'
