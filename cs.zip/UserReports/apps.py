from django.apps import AppConfig


class UserreportsConfig(AppConfig):
    name = 'UserReports'
